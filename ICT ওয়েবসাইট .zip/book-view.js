document.addEventListener('DOMContentLoaded', () => {
    // Page Elements
    const pageTitle = document.getElementById('pageTitle');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const mainImage = document.getElementById('mainImage');
    const pageIndicator = document.getElementById('pageIndicator');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');

    // Data for Book Views
    // এখানে প্রতিটি ছবির জন্য সার্চ ট্যাগ যুক্ত করুন
    const pageData = {
        'chapter1.html': {
            title: 'সম্পূর্ণ অধ্যায় পড়া',
            folder: '1png',
            images: [
                { file: 'page1.png', tags: ['ভূমিকা', 'ওয়েব ডিজাইন', 'html'] },
                { file: 'page2.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page3.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] }
                // প্রয়োজনে আরও ছবি ও ট্যাগ যোগ করুন
            ]
        },
        'chapter2.html': {
            title: 'দরকারি তথ্য',
            folder: '2png',
            images: [
                { file: 'page1.png', tags: ['গুরুত্বপূর্ণ', 'ট্যাগ লিস্ট'] },
                { file: 'page2.png', tags: ['অ্যাট্রিবিউট', 'উদাহরণ'] }
                // প্রয়োজনে আরও ছবি ও ট্যাগ যোগ করুন
            ]
        }
    };
    
    // Determine which page we are on
    const currentPagePath = window.location.pathname.split('/').pop();
    const config = pageData[currentPagePath];

    if (!config) {
        console.error('Configuration not found for this page.');
        return;
    }

    let currentPageIndex = 0;
    const totalPages = config.images.length;

    // Functions
    function renderPage(index) {
        if (index < 0 || index >= totalPages) return;
        
        currentPageIndex = index;
        const imageData = config.images[index];
        mainImage.src = `${config.folder}/${imageData.file}`;
        mainImage.style.animation = 'none';
        void mainImage.offsetWidth; // Trigger reflow to restart animation
        mainImage.style.animation = 'fadeIn 0.8s ease';
        
        pageIndicator.textContent = `পৃষ্ঠা ${index + 1} / ${totalPages}`;
        
        prevPageBtn.disabled = index === 0;
        nextPageBtn.disabled = index === totalPages - 1;
    }

    function searchByTag() {
        const query = searchInput.value.trim().toLowerCase();
        if (!query) return;

        const foundIndex = config.images.findIndex(img => 
            img.tags.some(tag => tag.toLowerCase().includes(query))
        );

        if (foundIndex !== -1) {
            renderPage(foundIndex);
        } else {
            alert('এই ট্যাগ দিয়ে কিছু পাওয়া যায়নি।');
        }
    }
    
    // Initial Setup
    pageTitle.textContent = config.title;
    document.title = config.title; // Set browser tab title
    renderPage(0);

    // Event Listeners
    prevPageBtn.addEventListener('click', () => renderPage(currentPageIndex - 1));
    nextPageBtn.addEventListener('click', () => renderPage(currentPageIndex + 1));
    searchButton.addEventListener('click', searchByTag);
    searchInput.addEventListener('keyup', (event) => {
        if (event.key === 'Enter') {
            searchByTag();
        }
    });
});