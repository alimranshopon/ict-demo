document.addEventListener('DOMContentLoaded', () => {
    const itemList = document.getElementById('itemList');
    const mainImage = document.getElementById('mainImage');
    const imageViewer = document.querySelector('.image-viewer');

    // MCQpng ফোল্ডারের সব ছবির লিস্ট এখানে যোগ করুন
    const mcqs = [
        { title: 'ঢাকা বোর্ড ২০২১', file: 'daka2021.png' },
        { title: 'রাজশাহী বোর্ড ২০২১', file: 'rajshahi2021.png' },
        { title: 'দিনাজপুর বোর্ড ২০১৯', file: 'dinajpur2019.png' },
        // এখানে আপনার MCQpng ফোল্ডারের সব ছবির নাম যোগ করুন
    ];

    if (mcqs.length === 0) {
        itemList.innerHTML = '<p>কোনো MCQ প্রশ্ন যোগ করা হয়নি।</p>';
        return;
    }

    mcqs.forEach(mcq => {
        const button = document.createElement('button');
        button.textContent = mcq.title;
        button.classList.add('btn', 'item-btn');
        button.addEventListener('click', () => {
            mainImage.src = `MCQpng/${mcq.file}`;
            mainImage.alt = mcq.title;
            imageViewer.style.display = 'block'; // Show the image viewer
        });
        itemList.appendChild(button);
    });

    // Hide image viewer initially
    imageViewer.style.display = 'none';
});