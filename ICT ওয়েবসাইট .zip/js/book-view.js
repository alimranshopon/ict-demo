document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const pageTitle = document.getElementById('pageTitle');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton'); // বাটনটিকে সিলেক্ট করা
    const mainImage = document.getElementById('mainImage');
    const pageIndicator = document.getElementById('pageIndicator');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');

    // --- ছবির ডেটাবেস ---
    // এখানে আপনার সব ছবির তথ্য যোগ করুন
    const pageData = {
        'chapter1.html': {
            title: 'সম্পূর্ণ অধ্যায় পড়া',
            folder: '1png',
            images: [
                // 1png ফোল্ডারের সব ছবির নাম এখানে যোগ করুন
                { file: 'page1.png', tags: ['1', '01', '174', '১৭৪'] },
                { file: 'page2.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page3.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page4.png', tags: ['লিঙ্ক', 'ছবি'] },
                { file: 'page5.png', tags: ['ভূমিকা', 'imran', 'html'] },
                { file: 'page6.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page7.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page8.png', tags: ['লিঙ্ক', 'ছবি'] },
                { file: 'page9.png', tags: ['ভূমিকা', 'imran', 'html'] },
                { file: 'page10.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page11.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page12.png', tags: ['লিঙ্ক', '04'] },
                { file: 'page13.png', tags: ['ভূমিকা', 'imran', 'html'] },
                { file: 'page14.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page15.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page16.png', tags: ['লিঙ্ক', 'ছবি'] },
                { file: 'page17.png', tags: ['ভূমিকা', 'imran', 'html'] },
                { file: 'page18.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page19.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page20.png', tags: ['লিঙ্ক', 'ছবি'] },
                { file: 'page21.png', tags: ['ভূমিকা', 'imran', 'html'] },
                { file: 'page22.png', tags: ['ট্যাগ', 'এলিমেন্ট', 'হেডিং'] },
                { file: 'page23.png', tags: ['প্যারাগ্রাফ', 'ফরম্যাটিং'] },
                { file: 'page24.png', tags: ['লিঙ্ক', '04'] },
                  
            ]
        },
        'chapter2.html': {
            title: 'দরকারি তথ্য',
            folder: '2png',
            images: [
                // 2png ফোল্ডারের সব ছবির নাম এখানে যোগ করুন
                { file: 'page1.png', tags: ['গুরুত্বপূর্ণ', 'ট্যাগ লিস্ট'] },
                { file: 'page2.png', tags: ['অ্যাট্রিবিউট', 'উদাহরণ'] },
                { file: 'page3.png', tags: ['কালার কোড', 'হেক্স'] },
                // ... আপনার যতগুলো দরকারি তথ্যের ছবি আছে, সব যোগ করুন
            ]
        }
    };
    
    // বর্তমান পেজ কোনটি তা নির্ধারণ করা
    const currentPagePath = window.location.pathname.split('/').pop();
    const config = pageData[currentPagePath];

    // কনফিগারেশন সঠিক আছে কিনা তা পরীক্ষা করা
    if (!config || !config.images || config.images.length === 0) {
        pageTitle.textContent = 'ত্রুটি';
        mainImage.alt = 'এই সেকশনের জন্য কোনো ছবি যোগ করা হয়নি। অনুগ্রহ করে js/book-view.js ফাইলটি চেক করুন।';
        console.error('Configuration not found or empty for this page:', currentPagePath);
        // বাটনগুলো নিষ্ক্রিয় করে দেওয়া
        if(prevPageBtn) prevPageBtn.disabled = true;
        if(nextPageBtn) nextPageBtn.disabled = true;
        if(searchButton) searchButton.disabled = true;
        return;
    }

    let currentPageIndex = 0;
    const totalPages = config.images.length;

    // --- Functions ---
    function renderPage(index) {
        if (index < 0 || index >= totalPages) return;
        
        currentPageIndex = index;
        const imageData = config.images[index];
        mainImage.src = `${config.folder}/${imageData.file}`;
        mainImage.alt = imageData.tags.join(', ');
        
        mainImage.style.animation = 'none';
        void mainImage.offsetWidth; 
        mainImage.style.animation = 'fadeIn 0.5s ease';
        
        pageIndicator.textContent = `পৃষ্ঠা ${index + 1} / ${totalPages}`;
        
        prevPageBtn.disabled = index === 0;
        nextPageBtn.disabled = index === totalPages - 1;
    }

    function searchByTag() {
        const query = searchInput.value.trim().toLowerCase();
        if (!query) return;

        // ফাইলের নাম দিয়ে সার্চ (যেমন: "page1") অথবা ট্যাগ দিয়ে সার্চ
        const foundIndex = config.images.findIndex(img => 
            img.file.toLowerCase().startsWith(query) || 
            img.tags.some(tag => tag.toLowerCase().includes(query))
        );

        if (foundIndex !== -1) {
            renderPage(foundIndex);
        } else {
            alert('এই নামে বা ট্যাগ দিয়ে কিছু পাওয়া যায়নি।');
        }
    }
    
    // --- Initial Setup & Event Listeners ---
    pageTitle.textContent = config.title;
    document.title = config.title; 
    renderPage(0);

    prevPageBtn.addEventListener('click', () => renderPage(currentPageIndex - 1));
    nextPageBtn.addEventListener('click', () => renderPage(currentPageIndex + 1));

    // !!! এই দুটি লাইন সার্চ বারকে কাজ করানোর জন্য জরুরি !!!
    searchButton.addEventListener('click', searchByTag); // বাটনে ক্লিকের জন্য
    searchInput.addEventListener('keyup', (event) => { // এন্টার কী চাপার জন্য
        if (event.key === 'Enter') {
            searchByTag();
        }
    });
});